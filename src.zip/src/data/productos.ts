export interface Producto {
 id: number|string; nombre:string; categoria:'zapatillas'|'iphones'|'tecnologia'; marca:string; modelo:string; tipo?:string; condicion?:string; precio:number; precioOferta?:number; imagenes:string[]; estado:'stock'|'pedido'|'agotado'; tallas?:string[]; capacidad?:string; bateria?:string; destacado?:boolean;
}
const foto = (id:string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=800&q=85`;
const sneaker = foto('photo-1595950653106-6c9ebd614d3a');
const phone = foto('photo-1695048133142-1a20484d2569');
const keyboard = foto('photo-1587829741301-dc798b83add3');
export const productos: Producto[] = [
{id:'zap-01',nombre:'Nike Dunk Low Retro',marca:'Nike',modelo:'Dunk Low',categoria:'zapatillas',precio:480,precioOferta:420,estado:'stock',tallas:['US 8','US 8.5','US 9','US 10'],imagenes:[sneaker],destacado:true},
{id:'zap-02',nombre:'Air Jordan 1 Retro High',marca:'Jordan',modelo:'Retro 1',categoria:'zapatillas',precio:890,estado:'pedido',tallas:['US 8','US 9','US 10'],imagenes:[foto('photo-1600185365483-26d7a4cc7519')],destacado:true},
{id:'zap-03',nombre:'Adidas Samba OG',marca:'Adidas',modelo:'Samba',categoria:'zapatillas',precio:520,estado:'stock',tallas:['US 7','US 8','US 9'],imagenes:[foto('photo-1542291026-7eec264c27ff')]},
{id:'zap-04',nombre:'New Balance 550',marca:'New Balance',modelo:'550',categoria:'zapatillas',precio:650,estado:'agotado',tallas:['US 8','US 9'],imagenes:[sneaker]},
{id:'iph-01',nombre:'iPhone 15 Pro',marca:'Apple',modelo:'iPhone 15 Pro',categoria:'iphones',precio:3600,estado:'stock',capacidad:'128 GB',condicion:'Sellado',bateria:'100%',imagenes:[phone],destacado:true},
{id:'iph-02',nombre:'iPhone 15',marca:'Apple',modelo:'iPhone 15',categoria:'iphones',precio:2900,precioOferta:2690,estado:'pedido',capacidad:'256 GB',condicion:'Sellado',imagenes:[phone]},
{id:'iph-03',nombre:'iPhone 14 Pro',marca:'Apple',modelo:'iPhone 14 Pro',categoria:'iphones',precio:2450,estado:'stock',capacidad:'128 GB',condicion:'Seminuevo',bateria:'90%',imagenes:[foto('photo-1592750475338-74b7b21085ab')]},
{id:'iph-04',nombre:'iPhone 13',marca:'Apple',modelo:'iPhone 13',categoria:'iphones',precio:1800,estado:'agotado',capacidad:'128 GB',condicion:'Seminuevo',imagenes:[phone]},
{id:'tech-01',nombre:'Redragon Kumara K552 RGB',marca:'Redragon',modelo:'Kumara K552',tipo:'Teclados',categoria:'tecnologia',precio:180,precioOferta:150,estado:'stock',imagenes:[keyboard],destacado:true},
{id:'tech-02',nombre:'Logitech G Pro Wireless',marca:'Logitech',modelo:'G Pro',tipo:'Mouse',categoria:'tecnologia',precio:390,estado:'pedido',imagenes:[foto('photo-1527814050087-3793815479db')]},
{id:'tech-03',nombre:'Sony WH-1000XM5',marca:'Sony',modelo:'WH-1000XM5',tipo:'Audio',categoria:'tecnologia',precio:1250,estado:'pedido',imagenes:[foto('photo-1546435770-a3e426bf472b')]},
{id:'tech-04',nombre:'Logitech MX Keys',marca:'Logitech',modelo:'MX Keys',tipo:'Teclados',categoria:'tecnologia',precio:490,estado:'agotado',imagenes:[keyboard]},
];
