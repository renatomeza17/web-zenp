type Item = {index:number; [key:string]:string|number|undefined};
const normalize = (v:unknown) => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
export function filtrarYOrdenar(items:Item[],query:string,filters:Record<string,string>,offers:boolean,sort:string) {
 const words = normalize(query).trim().split(/\s+/).filter(Boolean);
 const result = items.filter(p => words.every(w => normalize(`${p.title} ${p.brand} ${p.model} ${p.type} ${p.capacity} ${p.condition}`).includes(w)) && Object.entries(filters).every(([key,value]) => !value || (key === 'size' ? String(p.sizes || '').split('|').includes(value) : p[key] === value)) && (!offers || p.offer === 'true'));
 return result.sort((a,b) => sort === 'price-asc' ? Number(a.price)-Number(b.price) : sort === 'price-desc' ? Number(b.price)-Number(a.price) : sort === 'name' || sort === 'model' ? String(a[sort === 'name' ? 'title' : 'model']).localeCompare(String(b[sort === 'name' ? 'title' : 'model']),'es',{numeric:true}) : a.index-b.index);
}
